package com.example.tvlauncher.data

import android.content.Context

/**
 * Remembers a list of app package names under one key, for example the apps the user
 * hid or the apps opened most recently. The order of the list is kept.
 */
class PackageListStore(context: Context, private val key: String) {

    private val prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    fun load(): List<String> =
        prefs.getString(key, null)
            ?.split('\n')
            ?.filter { it.isNotBlank() }
            ?: emptyList()

    fun save(packages: List<String>) {
        prefs.edit().putString(key, packages.joinToString("\n")).apply()
    }
}
