package com.example.tvlauncher.ui

import android.content.Intent
import android.text.format.DateFormat
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.tvlauncher.R
import com.example.tvlauncher.data.AppEntry
import com.example.tvlauncher.data.WatchNextItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay

private val RowVerticalPadding = 10.dp
private val ContinueRowHeight = 178.dp
private val SideMargin = 56.dp

/** Width of a "Continue watching" card. The height follows the 16:9 shape. */
private val WatchCardWidth = 220.dp

/** Space kept free at the top for the clock, so the rows never touch it. */
private const val ClockAreaDp = 92f

/** Height of the two rows together (labels and tiles). Used to place them. */
private const val ContentHeightDp = 384f

@Composable
fun HomeScreen(
    /** Only the apps the user picked for the home screen. */
    apps: List<AppEntry>,
    watchNext: List<WatchNextItem>,
    watchNextAllowed: Boolean,
    /** False when the Home button does not open this launcher; a "Make default" button shows. */
    isDefaultHome: Boolean,
    onMakeDefault: () -> Unit,
    onLaunch: (Intent) -> Unit,
    onLaunchApp: (AppEntry, Rect) -> Unit,
    onOpenApps: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenWallpaper: () -> Unit,
    onRequestWatchNext: () -> Unit,
) {
    // The home screen is the root: Back does nothing here.
    BackHandler(enabled = true) { }

    val firstTile = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        // Wait one moment so the first tile exists before asking for focus.
        delay(150)
        runCatching { firstTile.requestFocus() }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        // Put the two rows in the middle of the screen. On a small screen they start right
        // under the clock; on a big one they sit a little above the exact centre.
        val freeDp = maxHeight.value - ContentHeightDp
        val topDp = (freeDp / 2f + 40f).coerceIn(ClockAreaDp, maxOf(ClockAreaDp, freeDp - 8f))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = topDp.dp),
        ) {
            SectionLabel(
                iconRes = R.drawable.ic_apps,
                text = "My apps",
                modifier = Modifier.padding(start = SideMargin),
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = SideMargin, vertical = RowVerticalPadding),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                itemsIndexed(apps, key = { _, app -> app.packageName }) { index, app ->
                    AppTile(
                        app = app,
                        onClick = { bounds -> onLaunchApp(app, bounds) },
                        focusRequester = if (index == 0) firstTile else null,
                    )
                }
                item(key = "all-apps") {
                    ActionTile(
                        iconRes = R.drawable.ic_apps,
                        label = if (apps.isEmpty()) "Add apps" else "All apps",
                        onClick = onOpenApps,
                        focusRequester = if (apps.isEmpty()) firstTile else null,
                    )
                }
            }

            Spacer(Modifier.height(6.dp))
            SectionLabel(
                iconRes = R.drawable.ic_play,
                text = "Continue watching",
                modifier = Modifier.padding(start = SideMargin),
            )
            ContinueArea(
                watchNext = watchNext,
                allowed = watchNextAllowed,
                onLaunch = onLaunch,
                onRequest = onRequestWatchNext,
            )
        }

        ClockDate(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = SideMargin, top = 16.dp),
        )

        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 20.dp, end = SideMargin),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (!isDefaultHome) {
                PillButton(iconRes = R.drawable.ic_home, label = "Make default", onClick = onMakeDefault)
            }
            PillButton(iconRes = R.drawable.ic_apps, label = "Apps", onClick = onOpenApps)
            PillButton(iconRes = R.drawable.ic_settings, label = "Settings", onClick = onOpenSettings)
            PillButton(iconRes = R.drawable.ic_wallpaper, label = "Background", onClick = onOpenWallpaper)
        }
    }
}

/** Time and date in the top left corner. It follows the TV's 12 / 24 hour setting and language. */
@Composable
private fun ClockDate(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(10_000)
        }
    }

    val time = DateFormat.getTimeFormat(context).format(Date(now))
    val datePattern = remember {
        DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM")
    }
    val date = SimpleDateFormat(datePattern, Locale.getDefault())
        .format(Date(now))
        .replaceFirstChar { it.uppercase() }

    val shadow = TextStyle(shadow = Shadow(Color(0xB3000000), Offset(0f, 2f), 8f))
    Column(modifier = modifier) {
        Text(
            text = time,
            color = Color.White,
            fontSize = 40.sp,
            fontWeight = FontWeight.SemiBold,
            style = shadow,
        )
        Text(
            text = date,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            style = shadow,
        )
    }
}

/**
 * The "Continue watching" row: the same list the TV's own home screen shows ("Ma sélection").
 * Each card is a wide picture with a bar for how much was watched; the title shows under the
 * selected card. Its height is the same in every state, so the screen never jumps around.
 */
@Composable
private fun ContinueArea(
    watchNext: List<WatchNextItem>,
    allowed: Boolean,
    onLaunch: (Intent) -> Unit,
    onRequest: () -> Unit,
) {
    when {
        !allowed -> {
            LazyRow(
                modifier = Modifier.height(ContinueRowHeight),
                contentPadding = PaddingValues(horizontal = SideMargin, vertical = RowVerticalPadding),
            ) {
                item(key = "turn-on") { TurnOnTile(onClick = onRequest) }
            }
        }

        watchNext.isEmpty() -> {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(ContinueRowHeight)
                    .padding(horizontal = SideMargin),
                contentAlignment = Alignment.CenterStart,
            ) {
                Text(
                    text = "Nothing to continue yet. Start a film or series in Stremio, Nuvio or another " +
                        "streaming app and it will appear here.",
                    color = SubtleText,
                    fontSize = 14.sp,
                )
            }
        }

        else -> {
            LazyRow(
                modifier = Modifier.height(ContinueRowHeight),
                contentPadding = PaddingValues(horizontal = SideMargin, vertical = RowVerticalPadding),
                horizontalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                items(watchNext, key = { it.id }) { item ->
                    WatchCard(item = item, onClick = { item.intent?.let(onLaunch) })
                }
            }
        }
    }
}

/** A film or series: wide picture, a bar showing how far you got, and its title when selected. */
@Composable
private fun WatchCard(item: WatchNextItem, onClick: () -> Unit) {
    Tile(
        label = item.title,
        onClick = { onClick() },
        modifier = Modifier.width(WatchCardWidth),
        background = Brush.linearGradient(listOf(Color(0xFF2A2F42), Color(0xFF171A27))),
    ) {
        if (item.posterUri == null) {
            Text(
                text = item.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(12.dp),
            )
        } else {
            AsyncImage(
                model = item.posterUri,
                contentDescription = item.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
        if (item.progress > 0f) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .height(5.dp)
                    .background(Color(0x66FFFFFF)),
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth(item.progress)
                    .height(5.dp)
                    .background(Color.White),
            )
        }
    }
}

/** Shown while the TV has not let the launcher read the list. Selecting it explains how. */
@Composable
private fun TurnOnTile(onClick: () -> Unit) {
    Tile(
        label = "Turn on Continue watching",
        onClick = { onClick() },
        modifier = Modifier.width(WatchCardWidth),
        background = Brush.linearGradient(listOf(Color(0x66FFFFFF), Color(0x33FFFFFF))),
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            Icon(
                painter = painterResource(R.drawable.ic_play),
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(34.dp),
            )
            Text(
                text = "Turn on Continue watching",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
            )
        }
    }
}
