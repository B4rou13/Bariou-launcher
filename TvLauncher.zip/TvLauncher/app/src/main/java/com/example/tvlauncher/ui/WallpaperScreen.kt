package com.example.tvlauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tvlauncher.data.Wallpapers

/** Lets the user pick a built-in wallpaper or add their own image. */
@Composable
fun WallpaperScreen(
    selectedId: String,
    customWallpaper: ImageBitmap?,
    onSelect: (String) -> Unit,
    onAddImage: () -> Unit,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)

    val firstTile = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstTile.requestFocus() } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 56.dp, vertical = 24.dp),
    ) {
        Text(
            text = "Background",
            color = Color.White,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
        )
        Text(
            text = "Choose a built-in wallpaper or add your own image. Press Back to return.",
            color = SubtleText,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 2.dp),
        )
        Spacer(Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            // Room around the tiles, so the selected one can grow without being cut off.
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(18.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(Wallpapers.builtIn, key = { it.id }) { wallpaper ->
                WallpaperTile(
                    name = wallpaper.name,
                    selected = selectedId == wallpaper.id,
                    onClick = { onSelect(wallpaper.id) },
                    focusRequester = if (wallpaper.id == Wallpapers.builtIn.first().id) firstTile else null,
                ) {
                    Image(
                        painter = painterResource(wallpaper.thumb),
                        contentDescription = wallpaper.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            if (customWallpaper != null) {
                item(key = Wallpapers.CUSTOM_ID) {
                    WallpaperTile(
                        name = "My image",
                        selected = selectedId == Wallpapers.CUSTOM_ID,
                        onClick = { onSelect(Wallpapers.CUSTOM_ID) },
                    ) {
                        Image(
                            bitmap = customWallpaper,
                            contentDescription = "My image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }
            item(key = "add") {
                AddImageTile(onClick = onAddImage)
            }
        }
    }
}

/** One calm, even motion for everything on this screen: no bounce, just a soft ease. */
private fun <T> smoothTween() = tween<T>(durationMillis = 260, easing = FastOutSlowInEasing)

@Composable
private fun WallpaperTile(
    name: String,
    selected: Boolean,
    onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.045f else 1f,
        animationSpec = smoothTween(),
        label = "tileScale",
    )
    // The white ring fades in on focus and stays faint on the chosen wallpaper.
    val ring by animateFloatAsState(
        targetValue = if (focused) 1f else if (selected) 0.55f else 0f,
        animationSpec = smoothTween(),
        label = "tileRing",
    )
    // The tick pops in softly when this wallpaper is chosen.
    val check by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = smoothTween(),
        label = "tileCheck",
    )
    val shape = RoundedCornerShape(14.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .optionalFocusRequester(focusRequester)
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(Color(0xFF222633))
            .border(3.dp, Color.White.copy(alpha = ring), shape)
            .clickable(onClick = onClick),
    ) {
        content()
        Text(
            text = name,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xB3000000))))
                .padding(start = 12.dp, end = 12.dp, top = 18.dp, bottom = 8.dp),
        )
        if (selected || check > 0.01f) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .graphicsLayer {
                        scaleX = check
                        scaleY = check
                        alpha = check
                    }
                    .size(24.dp)
                    .clip(CircleShape)
                    .background(Color.White),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = Color(0xFF0B0E1B),
                    modifier = Modifier.size(16.dp),
                )
            }
        }
    }
}

@Composable
private fun AddImageTile(onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (focused) 1.045f else 1f,
        animationSpec = smoothTween(),
        label = "tileScale",
    )
    val shape = RoundedCornerShape(14.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(if (focused) Color(0x33FFFFFF) else Color(0x1AFFFFFF))
            .border(if (focused) 3.dp else 1.dp, if (focused) FocusColor else Color(0x66FFFFFF), shape)
            .clickable(onClick = onClick),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            imageVector = Icons.Default.Add,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(32.dp),
        )
        Text(
            text = "Add your own image",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp),
        )
        Text(
            text = "From TV storage or a USB drive",
            color = SubtleText,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
        )
    }
}
