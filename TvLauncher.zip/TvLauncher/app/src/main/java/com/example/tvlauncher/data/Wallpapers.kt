package com.example.tvlauncher.data

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.tvlauncher.R
import java.io.File

data class Wallpaper(
    val id: String,
    val name: String,
    @DrawableRes val res: Int,
    /** Small version shown in the wallpaper picker, so the full images are not all decoded at once. */
    @DrawableRes val thumb: Int,
)

object Wallpapers {
    const val CUSTOM_ID = "custom"

    val builtIn = listOf(
        Wallpaper("pixel_sky", "Pixel sky", R.drawable.wp_pixel_sky, R.drawable.wp_pixel_sky_thumb),
        Wallpaper("cats", "Cat parade", R.drawable.wp_cats, R.drawable.wp_cats_thumb),
        Wallpaper("misty_peaks", "Misty peaks", R.drawable.wp_misty_peaks, R.drawable.wp_misty_peaks_thumb),
    )

    fun byId(id: String): Wallpaper = builtIn.firstOrNull { it.id == id } ?: builtIn.first()
}

/** Remembers which wallpaper is selected and keeps the user's own image. */
class WallpaperStore(private val context: Context) {

    private val prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)
    private val customFile = File(context.filesDir, "wallpaper_custom")

    var selectedId: String
        get() {
            val saved = prefs.getString("wallpaper", null)
            // A choice saved by an older version (removed wallpaper) falls back to the first one.
            val known = saved == Wallpapers.CUSTOM_ID || Wallpapers.builtIn.any { it.id == saved }
            return if (known && saved != null) saved else Wallpapers.builtIn.first().id
        }
        set(value) {
            prefs.edit().putString("wallpaper", value).apply()
        }

    /** Copies the picked image into the app's private storage. Returns false if it is not a readable image. */
    fun saveCustom(uri: Uri): Boolean {
        val temp = File(context.filesDir, "wallpaper_custom.tmp")
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                temp.outputStream().use { output -> input.copyTo(output) }
            } ?: return false

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(temp.path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                temp.delete()
                return false
            }
            customFile.delete()
            temp.renameTo(customFile)
        } catch (e: Exception) {
            temp.delete()
            false
        }
    }

    /** Loads the saved image, scaled down so it never exceeds about 1920 px wide. */
    fun loadCustom(): ImageBitmap? {
        if (!customFile.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(customFile.path, bounds)
        if (bounds.outWidth <= 0) return null

        var sample = 1
        while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2

        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(customFile.path, options)?.asImageBitmap()
    }
}
