package com.example.tvlauncher.data

import android.content.Context

/** Remembers which apps the user picked for the home screen, in the order they were picked. */
class FavoritesStore(context: Context) {

    private val prefs = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    fun load(): List<String> =
        prefs.getString(KEY, null)
            ?.split('\n')
            ?.filter { it.isNotBlank() }
            ?: emptyList()

    fun save(packages: List<String>) {
        prefs.edit().putString(KEY, packages.joinToString("\n")).apply()
    }

    private companion object {
        const val KEY = "favorites"
    }
}
