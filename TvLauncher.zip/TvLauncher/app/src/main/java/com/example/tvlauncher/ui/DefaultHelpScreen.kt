package com.example.tvlauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tvlauncher.R
import kotlinx.coroutines.delay

private const val SetHomeCommand = "cmd package set-home-activity com.example.tvlauncher/.MainActivity"

private const val GrantWatchNextCommand =
    "pm grant com.example.tvlauncher android.permission.READ_TV_LISTINGS"

/** Explains how to make TV Launcher the home app, for TVs with no screen to pick it. */
@Composable
fun DefaultHelpScreen(onClose: () -> Unit) {
    CommandHelpScreen(
        title = "Make TV Launcher your home app",
        intro = "Android does not let an app make itself the default. Use one of these:",
        steps = listOf(
            "1. Press the Home button on your remote. If the TV asks which home app " +
                "to use, choose TV Launcher, then Always.",
            "2. Or open your TV's Settings, then Apps, then Default apps (or Home app) " +
                "and choose TV Launcher. The names change between TVs.",
            "3. Or run this command once, with an adb app such as LADB or from a computer " +
                "(from a computer, start it with \"adb shell\"):",
        ),
        command = SetHomeCommand,
        onClose = onClose,
    )
}

/** Explains how to let the launcher read the TV's "Continue watching" list. */
@Composable
fun WatchNextHelpScreen(onClose: () -> Unit) {
    CommandHelpScreen(
        title = "Turn on Continue watching",
        intro = "Your TV keeps a list of what you were watching, the one its own home screen shows. " +
            "Android only lets this launcher read it after a one-time permission:",
        steps = listOf(
            "1. On the TV, install an adb app such as LADB. In Settings, Developer options, " +
                "turn on Wireless debugging and pair it with the app (needs Android 11 or newer). " +
                "Or use a computer with adb.",
            "2. Run this command once (from a computer, start it with \"adb shell\"):",
            "3. Close this card and reopen the launcher. The row fills with your films and series.",
        ),
        command = GrantWatchNextCommand,
        commandAfterStep = 2,
        onClose = onClose,
    )
}

/**
 * A card with a title, numbered steps and one command the person can copy. The command shows
 * after step [commandAfterStep] (the last step by default).
 */
@Composable
private fun CommandHelpScreen(
    title: String,
    intro: String,
    steps: List<String>,
    command: String,
    onClose: () -> Unit,
    commandAfterStep: Int = steps.size,
) {
    BackHandler(onBack = onClose)

    val clipboard = LocalClipboardManager.current
    val firstButton = remember { FocusRequester() }
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { firstButton.requestFocus() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 56.dp),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 700.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xE60B0E1B))
                .padding(28.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(
                text = title,
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
            )
            Text(text = intro, color = SubtleText, fontSize = 13.sp)

            steps.forEachIndexed { index, step ->
                Text(text = step, color = Color.White, fontSize = 14.sp)
                if (index + 1 == commandAfterStep) {
                    Text(
                        text = command,
                        color = Color.White,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x66000000))
                            .padding(12.dp),
                    )
                }
            }

            Row(
                modifier = Modifier.padding(top = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                PillButton(
                    iconRes = R.drawable.ic_home,
                    label = if (copied) "Copied" else "Copy command",
                    onClick = {
                        clipboard.setText(AnnotatedString(command))
                        copied = true
                    },
                    modifier = Modifier.focusRequester(firstButton),
                )
                PillButton(
                    iconRes = R.drawable.ic_apps,
                    label = "Close",
                    onClick = onClose,
                )
            }
        }
    }
}
