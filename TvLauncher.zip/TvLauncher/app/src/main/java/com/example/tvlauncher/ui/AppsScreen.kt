package com.example.tvlauncher.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.tvlauncher.R
import com.example.tvlauncher.data.AppEntry
import kotlinx.coroutines.delay

private enum class AppsMode { Browse, EditHome, Hide }

/**
 * Every installed app that is not hidden. Select one to open it.
 * - "Edit home apps": select an app to add it to the home screen or remove it.
 * - "Hide apps": select an app to hide it everywhere, or to show it again.
 */
@Composable
fun AppsScreen(
    apps: List<AppEntry>,
    favorites: List<String>,
    hidden: List<String>,
    onLaunchApp: (AppEntry, Rect) -> Unit,
    onToggleFavorite: (String) -> Unit,
    onToggleHidden: (String) -> Unit,
    onBack: () -> Unit,
) {
    var mode by remember { mutableStateOf(AppsMode.Browse) }
    BackHandler { if (mode != AppsMode.Browse) mode = AppsMode.Browse else onBack() }

    // Hidden apps only appear while choosing what to hide, so they can be shown again.
    val shown = if (mode == AppsMode.Hide) apps else apps.filter { it.packageName !in hidden }

    val firstApp = remember { FocusRequester() }
    LaunchedEffect(shown.isNotEmpty()) {
        if (shown.isNotEmpty()) {
            delay(150)
            runCatching { firstApp.requestFocus() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 24.dp),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 56.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                text = when (mode) {
                    AppsMode.Browse -> "All apps"
                    AppsMode.EditHome -> "Choose your home apps"
                    AppsMode.Hide -> "Hide apps"
                },
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
            )
            Spacer(Modifier.weight(1f))
            if (mode == AppsMode.Browse) {
                PillButton(
                    iconRes = R.drawable.ic_apps,
                    label = "Edit home apps",
                    onClick = { mode = AppsMode.EditHome },
                )
                PillButton(
                    iconRes = R.drawable.ic_hide,
                    label = "Hide apps",
                    onClick = { mode = AppsMode.Hide },
                )
            } else {
                PillButton(
                    iconRes = R.drawable.ic_apps,
                    label = "Done",
                    onClick = { mode = AppsMode.Browse },
                )
            }
        }
        Text(
            text = when (mode) {
                AppsMode.Browse -> "Select an app to open it."
                AppsMode.EditHome ->
                    "Select an app to add it to the home screen or remove it. Apps appear in the order you pick them."
                AppsMode.Hide ->
                    "Select an app to hide it. Apps with a tick are hidden. Select it again to show it."
            },
            color = SubtleText,
            fontSize = 13.sp,
            modifier = Modifier.padding(start = 56.dp, top = 4.dp),
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            contentPadding = PaddingValues(horizontal = 56.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            itemsIndexed(shown, key = { _, app -> app.packageName }) { index, app ->
                val isHidden = app.packageName in hidden
                AppTile(
                    app = app,
                    onClick = { bounds ->
                        when (mode) {
                            AppsMode.EditHome -> onToggleFavorite(app.packageName)
                            AppsMode.Hide -> onToggleHidden(app.packageName)
                            AppsMode.Browse -> onLaunchApp(app, bounds)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .alpha(if (mode == AppsMode.Hide && isHidden) 0.45f else 1f),
                    focusRequester = if (index == 0) firstApp else null,
                    badge = when (mode) {
                        AppsMode.EditHome -> app.packageName in favorites
                        AppsMode.Hide -> isHidden
                        AppsMode.Browse -> null
                    },
                )
            }
        }
    }
}
