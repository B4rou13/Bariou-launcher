package com.example.tvlauncher.data

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

object DefaultHome {

    /** True when pressing the Home button on the remote opens this launcher. */
    fun isDefault(context: Context): Boolean {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val info = context.packageManager.resolveActivity(home, PackageManager.MATCH_DEFAULT_ONLY)
        return info?.activityInfo?.packageName == context.packageName
    }
}
